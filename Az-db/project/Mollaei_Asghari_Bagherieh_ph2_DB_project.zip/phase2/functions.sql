-- function to create full name based on the userID

CREATE FUNCTION	personFullName (@personID int)
RETURNS nvarchar(200)
AS
BEGIN
	DECLARE @Result nvarchar(200);
	SELECT @Result=CONCAT(p.name, ' ', p.last_name)
	FROM Persons as p
	WHERE p.national_id = @personID

	RETURN @Result;

END
go
-- validate phone number

CREATE FUNCTION valid_phone_number (@phone_number nvarchar(20))
RETURNS INT
AS
BEGIN
	DECLARE @is_valid INT;
	SET @is_valid = 0;

	IF (LEN(@phone_number) = 13 AND SUBSTRING(@phone_number,1,1) = '+') OR LEN(@phone_number) = 12
	BEGIN
		RETURN ISNUMERIC(RIGHT(@phone_number, 12))
	END

	RETURN 0;


END
go
-- all doctors that a certain patient visited

CREATE FUNCTION patient_doctors (@patientID int)
RETURNS @result TABLE
(
	doctor_id int,
	doctor_name nvarchar(200),
	doctor_skill nvarchar(100)
)

AS
BEGIN
	INSERT INTO @result
	SELECT d.doctor_id, dbo.personFullName(d.national_id), d.skill
	FROM Patients as p JOIN Visits as v on p.patient_id = v.patient_id
	JOIN Doctors as d on v.doctor_id = v.doctor_id
	WHERE p.patient_id = @patientID

	RETURN



END
