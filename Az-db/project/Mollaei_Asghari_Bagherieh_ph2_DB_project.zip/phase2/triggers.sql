
-- Drug price history 
CREATE TABLE DrugPriceHistory (
    history_id INT IDENTITY(1,1) PRIMARY KEY,
    drug_id INT NOT NULL,
    name NVARCHAR(100),
    price_per_unit DECIMAL(10, 2),
    changed_at DATETIME DEFAULT GETDATE(),
    change_type NVARCHAR(10), -- 'INSERT' or 'UPDATE'
    FOREIGN KEY (drug_id) REFERENCES Drug(drug_id)
);

-- Trigger for logging drug price changes

CREATE OR ALTER TRIGGER trg_LogDrugPriceChanges
ON Drug
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Log new inserts
    INSERT INTO DrugPriceHistory (drug_id, name, price_per_unit, changed_at, change_type)
    SELECT 
        i.drug_id,
        i.name,
        i.price_per_unit,
        GETDATE(),
        'INSERT'
    FROM inserted AS i
    LEFT JOIN deleted d ON i.drug_id = d.drug_id
    WHERE d.drug_id IS NULL; -- Only in inserted, not in deleted (i.e., true insert)

    -- Log updates (only if price has changed)
    INSERT INTO DrugPriceHistory (drug_id, name, price_per_unit, changed_at, change_type)
    SELECT 
        i.drug_id,
        i.name,
        i.price_per_unit,
        GETDATE(),
        'UPDATE'
    FROM inserted AS i
    JOIN deleted d ON i.drug_id = d.drug_id
    WHERE i.price_per_unit != d.price_per_unit;
END;

-- Trigger to update the drugs_pay in Bill when a BillItem is inserted

CREATE OR ALTER TRIGGER trg_UpdateDrugsPayOnInsert
ON BillItem
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE b
    SET b.drugs_pay = ISNULL(b.drugs_pay, 0) + x.total_price
    FROM Bill b
    JOIN (
        SELECT 
            i.bill_id, 
            SUM(i.quantity * d.price_per_unit) AS total_price
        FROM inserted i
        JOIN Drug d ON i.drug_id = d.drug_id
        GROUP BY i.bill_id
    ) AS x
    ON b.bill_id = x.bill_id;
END;


-- Trigger to update the drugs_pay in Bill when a BillItem is deleted

CREATE OR ALTER TRIGGER trg_UpdateDrugsPayOnDelete
ON BillItem
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE b
    SET b.drugs_pay = ISNULL(b.drugs_pay, 0) - x.total_price
    FROM Bill b
    JOIN (
        SELECT 
            d.bill_id, 
            SUM(d.quantity * drug.price_per_unit) AS total_price
        FROM deleted d
        JOIN Drug drug ON d.drug_id = drug.drug_id
        GROUP BY d.bill_id
    ) AS x
    ON b.bill_id = x.bill_id;
END;



-- Trigger to recalculate the total and discounted_total in Bill when drugs_pay or doctor_pay changes based on insurance of patient

CREATE OR ALTER TRIGGER trg_RecalculateTotalsOnDrugOrDoctorPayChange
ON Bill
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE b
    SET 
        b.total = ISNULL(i.drugs_pay, 0) + ISNULL(i.doctor_pay, 0),
        b.discounted_total = 
            (ISNULL(i.drugs_pay, 0) + ISNULL(i.doctor_pay, 0)) *
            (1 - ISNULL(ins.discount, 0) / 100.0)
    FROM Bill b
    JOIN inserted i ON b.bill_id = i.bill_id
    LEFT JOIN Visits v ON v.bill_id = b.bill_id
    LEFT JOIN Patients p ON p.patient_id = v.patient_id
    LEFT JOIN Insurance ins ON ins.insurance_id = p.insurance_id;
END;



