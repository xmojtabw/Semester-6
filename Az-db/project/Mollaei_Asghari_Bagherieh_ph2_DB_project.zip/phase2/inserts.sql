-- Insert sample data into Disease table
INSERT INTO Disease (disease_id, name, type, description) VALUES
(1, 'Influenza', 'Viral', 'A contagious respiratory illness caused by influenza viruses.'),
(2, 'Diabetes', 'Chronic', 'A chronic condition that affects how the body processes blood sugar.'),
(3, 'Hypertension', 'Chronic', 'A condition in which the force of the blood against the artery walls is too high.'),
(4, 'COVID-19', 'Viral', 'A respiratory illness caused by the coronavirus SARS-CoV-2.'),
(5, 'Asthma', 'Chronic', 'A condition in which your airways narrow and swell and may produce extra mucus.');

-- Insert into Departments
INSERT INTO Departments (department_id, name, location) VALUES
(1, 'Cardiology', 'Building A'),
(2, 'Neurology', 'Building B'),
(3, 'Pediatrics', 'Building C');

-- Insert into Persons
INSERT INTO Persons (national_id, name, last_name, birth_year, address, phone_number) VALUES
(1001, 'John', 'Doe', 1980, '123 Main St', '555-1234'),
(1002, 'Jane', 'Smith', 1990, '456 Maple Ave', '555-5678'),
(1003, 'Emily', 'Clark', 1985, '789 Oak Dr', '555-9012'),
(1004, 'Michael', 'Brown', 1975, '321 Pine Rd', '555-3456'),
(1005,'test','test',1980,'isfahan','555-1235');

-- Insert into Insurance
INSERT INTO Insurance (insurance_id, company_name, discount) VALUES
(1, 'HealthCare Plus', 10.00),
(2, 'LifeSecure', 15.50);

-- Insert into Patients
INSERT INTO Patients (patient_id, national_id, department_id, insurance_id, description) VALUES
(1, 1001, 1, 1, 'Routine checkup'),
(2, 1002, 2, 2, 'Migraine treatment');

-- Insert into Employees
INSERT INTO Employees (employee_id, national_id, department_id, title) VALUES
(1, 1003, 3, 'Nurse'),
(2, 1004, 1, 'Surgeon');

-- Insert into Doctors
INSERT INTO Doctors (doctor_id, national_id, skill, education) VALUES
(1, 1004, 'Cardiothoracic Surgery', 'Harvard Medical School'),
(2, 1005, 'Cardiothoracic Surgery', 'Harvard Medical School');


-- Insert into Drug
INSERT INTO Drug (drug_id, price_per_unit, description, name) VALUES
(1, 5.00, 'Painkiller', 'Paracetamol'),
(2, 20.00, 'Anti-inflammatory', 'Ibuprofen');

-- Insert into Bill
INSERT INTO Bill (bill_id, doctor_pay, drugs_pay, total, discounted_total, date, status) VALUES
(1, 150.00, NULL, NULL, NULL, '2025-04-15', 'Paid'),
(2, 200.00, NULL, NULL, NULL, '2025-04-16', 'Unpaid'),
(3, 1500.00, NULL, NULL, NULL, '2025-04-15', 'Paid');


-- Insert into Visits
INSERT INTO Visits (visit_id, patient_id, doctor_id, bill_id, disease_id, status, patient_feedback, doctor_feedback, start_date, end_date, diagnosis) VALUES
(1, 1, 1, 1, 3, 'Completed', 'Very helpful', 'Routine case', '2025-04-15', '2025-04-15', 'Hypertension'),
(2, 2, 1, 2, 5, 'Ongoing', NULL, 'Monitoring symptoms', '2025-04-16', NULL, 'Migraine'),
(3, 2, 2, 3, 5, 'Ongoing', NULL, 'Monitoring symptoms', '2025-04-17', NULL, 'Migraine');

-- Insert into BillItem
INSERT INTO BillItem (billitem_id, bill_id, drug_id, quantity) VALUES
(1, 1, 1, 5),
(2, 1, 2, 1),
(3, 2, 2, 2);
