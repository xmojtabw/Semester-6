--view to see the monthly salary of each doctor near to his information
if object_id('DoctorMonthlySalaryView', 'v') is not null
    drop view doctormonthlysalaryview;
go

create view DoctorMonthlySalaryView as
select 
    d.doctor_id,
    d.skill,
    d.education,
    format(v.start_date, 'yyyy-MM') as salary_month,
    sum(case when b.status = 'Paid' then b.doctor_pay else 0 end) as monthly_salary
from doctors d
join visits v on d.doctor_id = v.doctor_id
join bill b on v.bill_id = b.bill_id
group by 
    d.doctor_id,
    d.skill,
    d.education,
    format(v.start_date, 'yyyy-MM');
go

-- it works perfectly
--select * from DoctorMonthlySalaryView


-------------------------------------------------------------
-- a view to show how many and what drugs each doctor prescribed
if object_id('doctor_drug_summary_view', 'v') is not null
    drop view doctor_drug_summary_view;
go

create view doctor_drug_summary_view as
select 
    d.doctor_id,
    dr.name as drug_name,
    sum(bi.quantity) as total_quantity_prescribed
from doctors d
join visits v on d.doctor_id = v.doctor_id
join bill b on v.bill_id = b.bill_id
join billitem bi on b.bill_id = bi.bill_id
join drug dr on bi.drug_id = dr.drug_id
group by 
    d.doctor_id,
    dr.name;
go

--select ddsv.* 
--from doctor_drug_summary_view as ddsv
--order by
--	ddsv.doctor_id


-----------------------------------------------------------------
--view that shows how much a patient spent and how many times he has visited a doctor
if object_id('patient_visit_summary_view', 'v') is not null
    drop view patient_visit_summary_view;
go

create view patient_visit_summary_view as
select 
    p.patient_id,
    count(v.visit_id) as completed_visits,
    sum(
        case 
            when v.status = 'Completed' then
                b.discounted_total
				--note that the discounted price in bill should be filled,maybe a trigger to calculate the discounted price if the patient has insurance?!?!
            else 0
        end
    ) as total_spent
from patients p
left join visits v on p.patient_id = v.patient_id
left join bill b on v.bill_id = b.bill_id
group by p.patient_id;
go

--select * from patient_visit_summary_view

------------------------------------------------------------------------------------