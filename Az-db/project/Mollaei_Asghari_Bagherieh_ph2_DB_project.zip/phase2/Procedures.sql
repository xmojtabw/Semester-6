-- find patients that haven't paid their bill in a week

CREATE OR ALTER PROCEDURE prc_unpaingin_patients 
AS
BEGIN
	SELECT dbo.personFullName(p.national_id), v.visit_id, b.bill_id
	FROM Visits as v JOIN Bill as b on v.bill_id = b.bill_id
	JOIN Patients as p on v.patient_id = p.patient_id
	WHERE b.status = 'Unpaid' AND DATEDIFF(DAY, b.date, GETDATE()) > 7
END

go

-- procedure to submit a new visit for given patient and doctor
CREATE OR ALTER PROCEDURE prc_register_visit @patientID int, @doctorID int
AS

BEGIN
	
	IF EXISTS 
	(
		SELECT 1
		FROM Doctors as d JOIN Visits as v on d.doctor_id = v.doctor_id
		WHERE d.doctor_id = @doctorID AND v.status = 'Ongoing'
	)

	BEGIN
		RAISERROR('Doctor is currently busy with another visit', 16, 1);
        RETURN;
	END

	INSERT INTO Visits (patient_id, doctor_id, bill_id, status, start_date) VALUES
						(@patientID, @doctorID, NULL, 'Ongoing', GETDATE());

END
go

CREATE OR ALTER PROCEDURE prc_expire_visits
AS
BEGIN

	UPDATE Visits
	SET status = 'Expired'
	WHERE status = 'Waiting' AND DATEDIFF(DAY, request_datetime, GETDATE()) > 7 


END
go


