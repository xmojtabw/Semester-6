mininet> iperf h1 h2
*** Iperf: testing TCP bandwidth between h1 and h2 
*** Results: ['1.0 Mbits/sec', '1.0 Mbits/sec']
mininet> iperf h2 h1
*** Iperf: testing TCP bandwidth between h2 and h1 
*** Results: ['1.0 Mbits/sec', '1.0 Mbits/sec']
mininet> iperf h2 h3
*** Iperf: testing TCP bandwidth between h2 and h3 
*** Results: ['84.1 Gbits/sec', '83.8 Gbits/sec']

hping3 --udp -p 53 -a 10.0.0.2 --flood 10.0.0.4

[  7]   0.00-10.21  sec  50.4 GBytes  42.4 Gbits/sec                  receiver
[  7]   0.00-10.00  sec  47.5 GBytes  40.8 Gbits/sec                  receiver
